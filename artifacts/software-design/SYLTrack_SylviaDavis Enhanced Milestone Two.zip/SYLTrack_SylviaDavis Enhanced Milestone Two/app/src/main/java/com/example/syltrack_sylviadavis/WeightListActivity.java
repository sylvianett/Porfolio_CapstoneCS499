package com.example.syltrack_sylviadavis;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.syltrack_sylviadavis.data.AppDatabaseHelper;

public class WeightListActivity extends AppCompatActivity {

    private AppDatabaseHelper db;
    private String loggedInUser;

    private TableLayout tableWeights;
    private EditText editDate, editWeight, editGoal;

    private Button buttonAddWeight;
    private Button buttonOpenSms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_list);

        db = new AppDatabaseHelper(this);

        // 🔐 Get logged-in user
        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE);
        loggedInUser = prefs.getString(MainActivity.KEY_LOGGED_IN_USER, null);

        if (loggedInUser == null) {
            Toast.makeText(this, "Please log in again.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        // UI refs
        tableWeights = findViewById(R.id.tableWeights);
        editDate = findViewById(R.id.editDate);
        editWeight = findViewById(R.id.editWeight);
        editGoal = findViewById(R.id.editGoal);

        buttonAddWeight = findViewById(R.id.buttonAddWeight);
        buttonOpenSms = findViewById(R.id.buttonOpenSms);

        buttonAddWeight.setOnClickListener(v -> addWeight());
        buttonOpenSms.setOnClickListener(v ->
                startActivity(new Intent(this, SmsActivity.class)));

        // ✅ Bottom nav (wired + highlight current tab)
        setupBottomNav();

        loadWeightsIntoTable();
    }

    private void setupBottomNav() {
        Button btnNavDashboard = findViewById(R.id.btnNavDashboard);
        Button btnNavWeights = findViewById(R.id.btnNavWeights);
        Button btnNavSms = findViewById(R.id.btnNavSms);

        // Highlight current screen (Weights)
        btnNavWeights.setEnabled(false);
        btnNavWeights.setAlpha(0.55f);

        btnNavDashboard.setEnabled(true);
        btnNavDashboard.setAlpha(1f);

        btnNavSms.setEnabled(true);
        btnNavSms.setAlpha(1f);

        btnNavDashboard.setOnClickListener(v ->
                startActivity(new Intent(this, DashboardActivity.class)));

        btnNavWeights.setOnClickListener(v -> {
            // already here
        });

        btnNavSms.setOnClickListener(v ->
                startActivity(new Intent(this, SmsActivity.class)));
    }

    private void addWeight() {
        String date = editDate.getText().toString().trim();
        String weightText = editWeight.getText().toString().trim();
        String goalText = editGoal.getText().toString().trim();

        if (TextUtils.isEmpty(date) || TextUtils.isEmpty(weightText) || TextUtils.isEmpty(goalText)) {
            Toast.makeText(this, "Please enter date, weight, and goal.", Toast.LENGTH_SHORT).show();
            return;
        }

        double weightValue;
        int goalValue;

        try {
            weightValue = Double.parseDouble(weightText);
            goalValue = Integer.parseInt(goalText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Weight and goal must be numeric.", Toast.LENGTH_SHORT).show();
            return;
        }

        long rowId = db.addWeight(loggedInUser, date, weightValue, goalValue);
        if (rowId != -1) {
            Toast.makeText(this, "Weight added!", Toast.LENGTH_SHORT).show();
            clearInputs();
            loadWeightsIntoTable();
        } else {
            Toast.makeText(this, "Insert failed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearInputs() {
        editDate.setText("");
        editWeight.setText("");
        editGoal.setText("");
    }

    private void loadWeightsIntoTable() {
        tableWeights.removeAllViews();
        Cursor cursor = null;

        try {
            cursor = db.getAllWeightsForUser(loggedInUser);

            // ✅ Always show a header row (better UX)
            addHeaderRow();

            if (cursor == null || cursor.getCount() == 0) {
                addMessageRow("No weights yet. Add your first entry to start tracking.");
                return;
            }

            int idIndex = cursor.getColumnIndexOrThrow(AppDatabaseHelper.COL_WEIGHT_ID);
            int dateIndex = cursor.getColumnIndexOrThrow(AppDatabaseHelper.COL_WEIGHT_DATE);
            int weightIndex = cursor.getColumnIndexOrThrow(AppDatabaseHelper.COL_WEIGHT_VALUE);
            int goalIndex = cursor.getColumnIndexOrThrow(AppDatabaseHelper.COL_WEIGHT_GOAL);

            while (cursor.moveToNext()) {
                long id = cursor.getLong(idIndex);
                String date = cursor.getString(dateIndex);
                double weight = cursor.getDouble(weightIndex);
                int goal = cursor.getInt(goalIndex);

                tableWeights.addView(buildDataRow(
                        id,
                        date,
                        String.valueOf(weight),
                        String.valueOf(goal)
                ));
            }

        } catch (Exception e) {
            Toast.makeText(this, "Error loading data: " + e.getMessage(), Toast.LENGTH_LONG).show();
            addMessageRow("Error loading weights.");
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    private void addHeaderRow() {
        TableRow header = new TableRow(this);
        header.setPadding(dp(4), dp(8), dp(4), dp(8));

        header.addView(makeHeaderCell("Date"));
        header.addView(makeHeaderCell("Weight"));
        header.addView(makeHeaderCell("Goal"));

        TextView deleteHeader = new TextView(this);
        deleteHeader.setText("Del");
        deleteHeader.setGravity(Gravity.START);
        deleteHeader.setPadding(dp(6), dp(6), dp(6), dp(6));
        deleteHeader.setTypeface(null, android.graphics.Typeface.BOLD);
        header.addView(deleteHeader);

        tableWeights.addView(header);
    }

    private TextView makeHeaderCell(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setLayoutParams(new TableRow.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        tv.setGravity(Gravity.START);
        tv.setPadding(dp(6), dp(6), dp(6), dp(6));
        tv.setTypeface(null, android.graphics.Typeface.BOLD);
        return tv;
    }

    private TableRow buildDataRow(long id, String date, String weight, String goal) {
        TableRow row = new TableRow(this);
        row.setPadding(dp(4), dp(8), dp(4), dp(8));

        row.addView(makeCell(date));
        row.addView(makeCell(weight));
        row.addView(makeCell(goal));

        Button btnDelete = new Button(this);
        btnDelete.setText("X");
        btnDelete.setOnClickListener(v -> deleteWeight(id));
        row.addView(btnDelete);

        return row;
    }

    private void deleteWeight(long id) {
        int rows = db.deleteWeight(id);
        if (rows > 0) {
            Toast.makeText(this, "Deleted.", Toast.LENGTH_SHORT).show();
            loadWeightsIntoTable();
        } else {
            Toast.makeText(this, "Delete failed.", Toast.LENGTH_SHORT).show();
        }
    }

    private TextView makeCell(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setLayoutParams(new TableRow.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        tv.setGravity(Gravity.START);
        tv.setPadding(dp(6), dp(6), dp(6), dp(6));
        return tv;
    }

    private void addMessageRow(String message) {
        TableRow row = new TableRow(this);
        TextView tv = new TextView(this);
        tv.setText(message);
        tv.setPadding(dp(8), dp(12), dp(8), dp(12));
        row.addView(tv);
        tableWeights.addView(row);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}
