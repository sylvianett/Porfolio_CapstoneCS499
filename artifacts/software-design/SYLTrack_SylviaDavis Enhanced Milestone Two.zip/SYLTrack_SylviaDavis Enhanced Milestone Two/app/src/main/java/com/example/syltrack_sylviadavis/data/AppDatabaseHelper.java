package com.example.syltrack_sylviadavis.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AppDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "syltrack.db";

    // bump version when schema changes
    private static final int DATABASE_VERSION = 4;

    // ===================== USERS TABLE =====================
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    private static final String SQL_CREATE_USERS =
            "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                    COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_USERNAME + " TEXT NOT NULL UNIQUE, " +
                    COL_PASSWORD + " TEXT NOT NULL" +
                    ");";

    // ===================== WEIGHTS TABLE =====================
    public static final String TABLE_WEIGHTS = "weights";
    public static final String COL_WEIGHT_ID = "id";
    public static final String COL_WEIGHT_DATE = "date";
    public static final String COL_WEIGHT_VALUE = "weight";
    public static final String COL_WEIGHT_GOAL = "goal";
    public static final String COL_WEIGHT_USERNAME = "username"; // NEW

    private static final String SQL_CREATE_WEIGHTS =
            "CREATE TABLE IF NOT EXISTS " + TABLE_WEIGHTS + " (" +
                    COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_WEIGHT_DATE + " TEXT NOT NULL, " +
                    COL_WEIGHT_VALUE + " REAL NOT NULL, " +
                    COL_WEIGHT_GOAL + " INTEGER NOT NULL, " +
                    COL_WEIGHT_USERNAME + " TEXT NOT NULL" +
                    ");";

    public AppDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_USERS);
        db.execSQL(SQL_CREATE_WEIGHTS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // simple rebuild for class project
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        onCreate(db);
    }

    // ===================== LOGIN HELPERS =====================

    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(
                    TABLE_USERS,
                    new String[]{COL_USER_ID},
                    COL_USERNAME + "=?",
                    new String[]{username},
                    null, null, null
            );
            return cursor != null && cursor.moveToFirst();
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
    }

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(COL_USERNAME, username);
            values.put(COL_PASSWORD, password);
            long result = db.insert(TABLE_USERS, null, values);
            return result != -1;
        } finally {
            db.close();
        }
    }

    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(
                    TABLE_USERS,
                    new String[]{COL_USER_ID},
                    COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                    new String[]{username, password},
                    null, null, null
            );
            return cursor != null && cursor.moveToFirst();
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
    }

    // ===================== WEIGHTS CRUD (PER USER) =====================

    public long addWeight(String username, String date, double weight, int goal) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(COL_WEIGHT_USERNAME, username);
            values.put(COL_WEIGHT_DATE, date);
            values.put(COL_WEIGHT_VALUE, weight);
            values.put(COL_WEIGHT_GOAL, goal);
            return db.insert(TABLE_WEIGHTS, null, values);
        } finally {
            db.close();
        }
    }

    public Cursor getAllWeightsForUser(String username) {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(
                TABLE_WEIGHTS,
                null,
                COL_WEIGHT_USERNAME + "=?",
                new String[]{username},
                null,
                null,
                COL_WEIGHT_DATE + " DESC, " + COL_WEIGHT_ID + " DESC"
        );
    }

    public int deleteWeight(long id) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            return db.delete(
                    TABLE_WEIGHTS,
                    COL_WEIGHT_ID + "=?",
                    new String[]{String.valueOf(id)}
            );
        } finally {
            db.close();
        }
    }
}
