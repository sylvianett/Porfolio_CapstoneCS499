package com.example.syltrack_sylviadavis;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * WeightAdapter
 * - Displays weights in a grid (RecyclerView)
 * - Clicking a card triggers edit/delete options
 */
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    public interface WeightClickListener {
        void onWeightClicked(WeightEntry entry);
    }

    private final List<WeightEntry> weights;
    private final WeightClickListener listener;

    public WeightAdapter(List<WeightEntry> weights, WeightClickListener listener) {
        this.weights = weights;
        this.listener = listener;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_card, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = weights.get(position);
        holder.textDate.setText(entry.date);
        holder.textWeight.setText(String.valueOf(entry.weight));

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onWeightClicked(entry);
        });
    }

    @Override
    public int getItemCount() {
        return weights.size();
    }

    static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView textDate;
        TextView textWeight;

        WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            textDate = itemView.findViewById(R.id.textDate);
            textWeight = itemView.findViewById(R.id.textWeight);
        }
    }
}
