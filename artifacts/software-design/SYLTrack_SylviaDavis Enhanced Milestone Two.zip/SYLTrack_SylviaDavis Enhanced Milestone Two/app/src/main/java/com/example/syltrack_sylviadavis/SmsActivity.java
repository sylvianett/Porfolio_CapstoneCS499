package com.example.syltrack_sylviadavis;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private static final int REQ_SEND_SMS = 1001;

    private EditText editPhoneNumber, editSmsMessage;
    private Button buttonSendSms, buttonBackToWeights;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        editSmsMessage = findViewById(R.id.editSmsMessage);
        buttonSendSms = findViewById(R.id.buttonSendSms);
        buttonBackToWeights = findViewById(R.id.buttonBackToWeights);

        buttonSendSms.setOnClickListener(v -> trySendSms());

        // Always go to Weights screen (more reliable than finish())
        buttonBackToWeights.setOnClickListener(v ->
                startActivity(new Intent(SmsActivity.this, WeightListActivity.class))
        );

        // ✅ Wire up bottom nav + highlight current screen
        setupBottomNav();
    }

    private void setupBottomNav() {
        Button btnNavDashboard = findViewById(R.id.btnNavDashboard);
        Button btnNavWeights = findViewById(R.id.btnNavWeights);
        Button btnNavSms = findViewById(R.id.btnNavSms);

        // Highlight current screen (Reminders)
        btnNavSms.setEnabled(false);
        btnNavSms.setAlpha(0.55f);

        btnNavDashboard.setEnabled(true);
        btnNavDashboard.setAlpha(1f);

        btnNavWeights.setEnabled(true);
        btnNavWeights.setAlpha(1f);

        btnNavDashboard.setOnClickListener(v ->
                startActivity(new Intent(SmsActivity.this, DashboardActivity.class))
        );

        btnNavWeights.setOnClickListener(v ->
                startActivity(new Intent(SmsActivity.this, WeightListActivity.class))
        );

        btnNavSms.setOnClickListener(v -> {
            // already here
        });
    }

    private void trySendSms() {
        String phone = editPhoneNumber.getText().toString().trim();
        String msg = editSmsMessage.getText().toString().trim();

        if (TextUtils.isEmpty(phone) || TextUtils.isEmpty(msg)) {
            Toast.makeText(this, "Please enter a phone number and message.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    REQ_SEND_SMS
            );
            return;
        }

        sendSmsNow(phone, msg);
    }

    private void sendSmsNow(String phone, String msg) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phone, null, msg, null, null);
            Toast.makeText(this, "SMS sent!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQ_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                trySendSms();
            } else {
                Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
