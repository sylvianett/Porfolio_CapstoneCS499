package com.example.syltrack_sylviadavis;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.syltrack_sylviadavis.data.AppDatabaseHelper;

public class DashboardActivity extends AppCompatActivity {

    private AppDatabaseHelper db;

    private TextView tvLatestWeight;
    private TextView tvGoal;
    private TextView tvToGoal;

    private Button btnGoToWeights;
    private Button btnGoToSms;

    private String loggedInUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        db = new AppDatabaseHelper(this);

        // Get logged-in user from SharedPreferences
        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE);
        loggedInUser = prefs.getString(MainActivity.KEY_LOGGED_IN_USER, null);

        if (loggedInUser == null) {
            Toast.makeText(this, "Please log in again.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        tvLatestWeight = findViewById(R.id.tvLatestWeight);
        tvGoal = findViewById(R.id.tvGoal);
        tvToGoal = findViewById(R.id.tvToGoal);

        btnGoToWeights = findViewById(R.id.btnGoToWeights);
        btnGoToSms = findViewById(R.id.btnGoToSms);

        btnGoToWeights.setOnClickListener(v ->
                startActivity(new Intent(DashboardActivity.this, WeightListActivity.class))
        );

        btnGoToSms.setOnClickListener(v ->
                startActivity(new Intent(DashboardActivity.this, SmsActivity.class))
        );

        // ✅ Wire up bottom nav (and highlight current screen)
        setupBottomNav();

        loadDashboardStats();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Re-load in case user changed weights/goals
        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE);
        loggedInUser = prefs.getString(MainActivity.KEY_LOGGED_IN_USER, null);

        if (loggedInUser != null) {
            loadDashboardStats();
        }
    }

    private void setupBottomNav() {
        Button btnNavDashboard = findViewById(R.id.btnNavDashboard);
        Button btnNavWeights = findViewById(R.id.btnNavWeights);
        Button btnNavSms = findViewById(R.id.btnNavSms);

        // Highlight current screen (Dashboard)
        btnNavDashboard.setEnabled(false);
        btnNavDashboard.setAlpha(0.55f);

        btnNavWeights.setEnabled(true);
        btnNavWeights.setAlpha(1f);

        btnNavSms.setEnabled(true);
        btnNavSms.setAlpha(1f);

        btnNavDashboard.setOnClickListener(v -> {
            // already here
        });

        btnNavWeights.setOnClickListener(v ->
                startActivity(new Intent(DashboardActivity.this, WeightListActivity.class))
        );

        btnNavSms.setOnClickListener(v ->
                startActivity(new Intent(DashboardActivity.this, SmsActivity.class))
        );
    }

    private void loadDashboardStats() {
        Cursor cursor = null;

        try {
            cursor = db.getAllWeightsForUser(loggedInUser);

            if (cursor == null || cursor.getCount() == 0) {
                tvLatestWeight.setText("Latest Weight: --");
                tvGoal.setText("Goal: --");
                tvToGoal.setText("To Goal: Add your first weight entry to start tracking progress!");
                return;
            }

            int weightIndex = cursor.getColumnIndexOrThrow(AppDatabaseHelper.COL_WEIGHT_VALUE);
            int goalIndex = cursor.getColumnIndexOrThrow(AppDatabaseHelper.COL_WEIGHT_GOAL);

            // Sorted DESC, first row = latest
            cursor.moveToFirst();
            double latestWeight = cursor.getDouble(weightIndex);
            int latestGoal = cursor.getInt(goalIndex);

            tvLatestWeight.setText("Latest Weight: " + latestWeight);
            tvGoal.setText("Goal: " + latestGoal);

            double diff = latestWeight - latestGoal;

            if (diff > 0) {
                tvToGoal.setText("To Goal: " + diff + " lbs to go");
            } else if (diff < 0) {
                tvToGoal.setText("To Goal: Goal reached! (" + Math.abs(diff) + " lbs under)");
            } else {
                tvToGoal.setText("To Goal: You hit your goal exactly!");
            }

        } catch (Exception e) {
            tvLatestWeight.setText("Latest Weight: --");
            tvGoal.setText("Goal: --");
            tvToGoal.setText("Dashboard error: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
        }
    }
}
